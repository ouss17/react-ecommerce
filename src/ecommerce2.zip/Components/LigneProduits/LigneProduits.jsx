import React from 'react'

import './ligneProduits.scss'

const LigneProduits = () => {
    return (
        <div>
            
        </div>
    )
}

export default LigneProduits
