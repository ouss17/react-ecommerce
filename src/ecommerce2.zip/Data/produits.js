const produits = [
    {
        id:1,
        titre:"Backpack",
        description:"Lorem ipsum dolor sit amet, consectetur adipiscing elit. Sed interdum pulvinar tristique. Duis quis dignissim ante. Curabitur volutpat fringilla nibh at pellentesque. Pellentesque maximus tortor ac molestie vestibulum. Praesent accumsan in arcu quis faucibus. Sed consequat, leo eu blandit commodo, ante turpis gravida leo, ac aliquam metus lorem quis ipsum. Donec consequat vulputate enim, vitae eleifend neque ornare at. Nunc a blandit nulla. ",
        descriptionCourte:"Lorem ipsum dolor sit amet, consectetur.",
        img:"https://tokmo.fr/public/cloudcampus/groupe2/ecommerce/produits/miniatures/sacsamain/1.jpg",
        prix:149,
        stock:10,
        categorie:'sacamain',
        promo:0
    },
    {
        id:2,
        titre:"Barrel",
        description:"Lorem ipsum dolor sit amet, consectetur adipiscing elit. Sed interdum pulvinar tristique. Duis quis dignissim ante. Curabitur volutpat fringilla nibh at pellentesque. Pellentesque maximus tortor ac molestie vestibulum. Praesent accumsan in arcu quis faucibus. Sed consequat, leo eu blandit commodo, ante turpis gravida leo, ac aliquam metus lorem quis ipsum. Donec consequat vulputate enim, vitae eleifend neque ornare at. Nunc a blandit nulla. ",
        descriptionCourte:"Lorem ipsum dolor sit amet, consectetur.",
        img:"https://tokmo.fr/public/cloudcampus/groupe2/ecommerce/produits/miniatures/sacsamain/2.jpg",
        prix:99,
        stock:1,
        categorie:'sacamain',
        promo:0
    },
    {
        id:3,
        titre:"Clutch",
        description:"Lorem ipsum dolor sit amet, consectetur adipiscing elit. Sed interdum pulvinar tristique. Duis quis dignissim ante. Curabitur volutpat fringilla nibh at pellentesque. Pellentesque maximus tortor ac molestie vestibulum. Praesent accumsan in arcu quis faucibus. Sed consequat, leo eu blandit commodo, ante turpis gravida leo, ac aliquam metus lorem quis ipsum. Donec consequat vulputate enim, vitae eleifend neque ornare at. Nunc a blandit nulla. ",
        descriptionCourte:"Lorem ipsum dolor sit amet, consectetur.",
        img:"https://tokmo.fr/public/cloudcampus/groupe2/ecommerce/produits/miniatures/sacsamain/3.jpg",
        prix:49,
        stock:100,
        categorie:'sacamain',
        promo:0
    },
    {
        id:4,
        titre:"Satchel",
        description:"Lorem ipsum dolor sit amet, consectetur adipiscing elit. Sed interdum pulvinar tristique. Duis quis dignissim ante. Curabitur volutpat fringilla nibh at pellentesque. Pellentesque maximus tortor ac molestie vestibulum. Praesent accumsan in arcu quis faucibus. Sed consequat, leo eu blandit commodo, ante turpis gravida leo, ac aliquam metus lorem quis ipsum. Donec consequat vulputate enim, vitae eleifend neque ornare at. Nunc a blandit nulla. ",
        descriptionCourte:"Lorem ipsum dolor sit amet, consectetur.",
        img:"https://tokmo.fr/public/cloudcampus/groupe2/ecommerce/produits/miniatures/sacsamain/4.jpg",
        prix:80,
        stock:54,
        categorie:'sacamain',
        promo:20
    },
    {
        id:5,
        titre:"Messenger",
        description:"Lorem ipsum dolor sit amet, consectetur adipiscing elit. Sed interdum pulvinar tristique. Duis quis dignissim ante. Curabitur volutpat fringilla nibh at pellentesque. Pellentesque maximus tortor ac molestie vestibulum. Praesent accumsan in arcu quis faucibus. Sed consequat, leo eu blandit commodo, ante turpis gravida leo, ac aliquam metus lorem quis ipsum. Donec consequat vulputate enim, vitae eleifend neque ornare at. Nunc a blandit nulla. ",
        descriptionCourte:"Lorem ipsum dolor sit amet, consectetur.",
        img:"https://tokmo.fr/public/cloudcampus/groupe2/ecommerce/produits/miniatures/sacsamain/5.jpg",
        prix:5999,
        stock:4,
        categorie:'sacamain',
        promo:0
    },
    {
        id:6,
        titre:"Hobo",
        description:"Lorem ipsum dolor sit amet, consectetur adipiscing elit. Sed interdum pulvinar tristique. Duis quis dignissim ante. Curabitur volutpat fringilla nibh at pellentesque. Pellentesque maximus tortor ac molestie vestibulum. Praesent accumsan in arcu quis faucibus. Sed consequat, leo eu blandit commodo, ante turpis gravida leo, ac aliquam metus lorem quis ipsum. Donec consequat vulputate enim, vitae eleifend neque ornare at. Nunc a blandit nulla. ",
        descriptionCourte:"Lorem ipsum dolor sit amet, consectetur.",
        img:"https://tokmo.fr/public/cloudcampus/groupe2/ecommerce/produits/miniatures/sacsamain/6.jpg",
        prix:8499,
        stock:2,
        categorie:'sacamain',
        promo:50
    },
    {
        id:7,
        titre:"Minaudiere",
        description:"Lorem ipsum dolor sit amet, consectetur adipiscing elit. Sed interdum pulvinar tristique. Duis quis dignissim ante. Curabitur volutpat fringilla nibh at pellentesque. Pellentesque maximus tortor ac molestie vestibulum. Praesent accumsan in arcu quis faucibus. Sed consequat, leo eu blandit commodo, ante turpis gravida leo, ac aliquam metus lorem quis ipsum. Donec consequat vulputate enim, vitae eleifend neque ornare at. Nunc a blandit nulla. ",
        descriptionCourte:"Lorem ipsum dolor sit amet, consectetur.",
        img:"https://tokmo.fr/public/cloudcampus/groupe2/ecommerce/produits/miniatures/sacsamain/7.jpg",
        prix:165,
        stock:30,
        categorie:'sacamain',
        promo:0
    },
    {
        id:8,
        titre:"Duffel",
        description:"Lorem ipsum dolor sit amet, consectetur adipiscing elit. Sed interdum pulvinar tristique. Duis quis dignissim ante. Curabitur volutpat fringilla nibh at pellentesque. Pellentesque maximus tortor ac molestie vestibulum. Praesent accumsan in arcu quis faucibus. Sed consequat, leo eu blandit commodo, ante turpis gravida leo, ac aliquam metus lorem quis ipsum. Donec consequat vulputate enim, vitae eleifend neque ornare at. Nunc a blandit nulla. ",
        descriptionCourte:"Lorem ipsum dolor sit amet, consectetur.",
        img:"https://tokmo.fr/public/cloudcampus/groupe2/ecommerce/produits/miniatures/sacsamain/8.jpg",
        prix:10,
        stock:1000,
        categorie:'sacamain',
        promo:0
    },

    
]


export default produits