import React from 'react'

import Card from '../Components/Produits/Card'

import './index.scss'

const Index = ({produits}) => {
    return (
        <section className="presentationProduit">
            <Card produit={produits[0]} />
     
        </section>
    )
}

export default Index
